// ZUMUYA GROUP — Edge Function « team-admin »
// Crée / suspend / réactive les comptes des EMPLOYÉS et des LIVREURS d'un restaurant (ou hôtel).
// Seule porte d'entrée pour créer un compte livreur : il n'existe plus d'inscription publique.
// Déploiement : supabase functions deploy team-admin   (secrets SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY fournis automatiquement)
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, "Content-Type": "application/json" } });
const PERMS = ["dash","pos","orders","menu","hist","report","drivers","stock","supply","finance","settings","team"];
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function genPassword() {
  const a = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
  const r = crypto.getRandomValues(new Uint32Array(10));
  return Array.from(r, (n) => a[n % a.length]).join("") + "7";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Méthode non autorisée" }, 405);

  const url = Deno.env.get("SUPABASE_URL")!, anon = Deno.env.get("SUPABASE_ANON_KEY")!, srv = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const auth = req.headers.get("Authorization") || "";
  const caller = createClient(url, anon, { global: { headers: { Authorization: auth } } });
  const { data: u, error: ue } = await caller.auth.getUser();
  if (ue || !u?.user) return json({ error: "Connexion requise" }, 401);
  const me = u.user.id;
  const admin = createClient(url, srv, { auth: { persistSession: false } });

  let b: any; try { b = await req.json(); } catch { return json({ error: "Requête invalide" }, 400); }
  const action = String(b.action || "");

  // Organisation de l'appelant : compte principal (owner_id) ou employé actif ayant la permission « team »
  async function authorize(orgId: string, kind: "staff" | "driver") {
    const { data: org } = await admin.from("rg_organizations").select("id,owner_id,public_name,organization_type").eq("id", orgId).maybeSingle();
    if (!org) return { ok: false as const, why: "Organisation introuvable" };
    if (org.owner_id === me) return { ok: true as const, org };
    const { data: m } = await admin.from("rg_team_members").select("permissions,status,kind").eq("org_id", orgId).eq("user_id", me).maybeSingle();
    if (m && m.kind === "staff" && m.status === "active" && (m.permissions || []).includes("team") && kind === "driver") return { ok: true as const, org };
    return { ok: false as const, why: "Accès refusé" };
  }

  try {
    if (action === "create") {
      const kind = b.kind === "driver" ? "driver" : b.kind === "staff" ? "staff" : null;
      if (!kind) return json({ error: "Type de compte invalide" }, 400);
      const orgId = String(b.org_id || "");
      const z = await authorize(orgId, kind); if (!z.ok) return json({ error: z.why }, 403);
      const org = z.org;
      if (!["restaurant", "hotel"].includes(String(org.organization_type))) return json({ error: "Seuls les restaurants et hôtels partenaires peuvent créer ces comptes" }, 403);

      const email = String(b.email || "").trim().toLowerCase();
      const name = String(b.name || "").trim();
      if (!EMAIL.test(email)) return json({ error: "Adresse e-mail invalide" }, 400);
      if (name.length < 2) return json({ error: "Nom obligatoire" }, 400);
      const password = String(b.password || "").length >= 8 ? String(b.password) : genPassword();
      const permissions = kind === "staff" ? (Array.isArray(b.permissions) ? b.permissions.filter((p: string) => PERMS.includes(p)) : []) : [];
      if (kind === "staff" && permissions.includes("team") && org.owner_id !== me) return json({ error: "Seul le compte principal peut donner la gestion d'équipe" }, 403);

      const { data: cu, error: ce } = await admin.auth.admin.createUser({
        email, password, email_confirm: true,
        user_metadata: { name, account_type: kind === "driver" ? "delivery" : "staff", organization_id: org.id, organization_name: org.public_name, managed_by_org: true },
        app_metadata: { managed_by_org: true, org_id: org.id },
      });
      if (ce || !cu?.user) return json({ error: /already|registered|exists/i.test(ce?.message || "") ? "Un compte existe déjà avec cet e-mail" : (ce?.message || "Création impossible") }, 400);

      const { data: m, error: me2 } = await admin.from("rg_team_members").insert({
        org_id: org.id, user_id: cu.user.id, kind, full_name: name, job_title: String(b.job_title || "").slice(0, 60) || null,
        phone: String(b.phone || "").slice(0, 30) || null, vehicle: String(b.vehicle || "").slice(0, 40) || null, permissions, created_by: me,
      }).select("id").single();
      if (me2) { await admin.auth.admin.deleteUser(cu.user.id); return json({ error: me2.message }, 400); }
      await admin.from("rg_audit_log").insert({ org_id: org.id, actor_id: me, action: "team.create", target: m.id, details: { kind, email, permissions } });
      return json({ ok: true, member_id: m.id, user_id: cu.user.id, email, password });
    }

    if (action === "set_status" || action === "reset_password" || action === "delete") {
      const { data: m } = await admin.from("rg_team_members").select("id,org_id,user_id,kind").eq("id", String(b.member_id || "")).maybeSingle();
      if (!m) return json({ error: "Membre introuvable" }, 404);
      const z = await authorize(m.org_id, m.kind); if (!z.ok) return json({ error: z.why }, 403);
      if (m.user_id === me) return json({ error: "Action impossible sur votre propre compte" }, 400);

      if (action === "set_status") {
        const st = String(b.status);
        if (!["active", "suspended", "disabled"].includes(st)) return json({ error: "Statut invalide" }, 400);
        await admin.from("rg_team_members").update({ status: st, updated_at: new Date().toISOString() }).eq("id", m.id);
        // une suspension coupe aussi la connexion (≈ 100 ans) ; la réactivation la rétablit
        await admin.auth.admin.updateUserById(m.user_id, { ban_duration: st === "active" ? "none" : "876000h" });
        await admin.from("rg_audit_log").insert({ org_id: m.org_id, actor_id: me, action: "team.status", target: m.id, details: { status: st } });
        return json({ ok: true });
      }
      if (action === "reset_password") {
        const password = String(b.password || "").length >= 8 ? String(b.password) : genPassword();
        const { error } = await admin.auth.admin.updateUserById(m.user_id, { password });
        if (error) return json({ error: error.message }, 400);
        await admin.from("rg_audit_log").insert({ org_id: m.org_id, actor_id: me, action: "team.password_reset", target: m.id, details: {} });
        return json({ ok: true, password });
      }
      // delete : suppression définitive du compte (les livraisons passées restent dans l'historique du restaurant)
      await admin.from("rg_audit_log").insert({ org_id: m.org_id, actor_id: me, action: "team.delete", target: m.id, details: { kind: m.kind } });
      await admin.auth.admin.deleteUser(m.user_id);
      return json({ ok: true });
    }
    return json({ error: "Action inconnue" }, 400);
  } catch (e) {
    return json({ error: String((e as Error).message || e) }, 500);
  }
});
